/*
 *      tools.h - this file is part of Geany, a fast and lightweight IDE
 *
 *      Copyright 2006 The Geany contributors
 *
 *      This program is free software; you can redistribute it and/or modify
 *      it under the terms of the GNU General Public License as published by
 *      the Free Software Foundation; either version 2 of the License, or
 *      (at your option) any later version.
 *
 *      This program is distributed in the hope that it will be useful,
 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *      GNU General Public License for more details.
 *
 *      You should have received a copy of the GNU General Public License along
 *      with this program; if not, write to the Free Software Foundation, Inc.,
 *      51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */


#ifndef GEANY_TOOLS_H
#define GEANY_TOOLS_H 1

#include "document.h"

#include <glib.h>

G_BEGIN_DECLS

void tools_create_insert_custom_command_menu_items(void);

void tools_execute_custom_command(GeanyDocument *doc, const gchar *command);

void tools_word_count(void);

void tools_color_chooser(const gchar *color);

G_END_DECLS

#endif /* GEANY_TOOLS_H */
