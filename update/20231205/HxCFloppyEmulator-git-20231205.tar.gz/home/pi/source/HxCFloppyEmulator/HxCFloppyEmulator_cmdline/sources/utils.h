
void get_filename(char * path,char * filename);
