
extern USHORT left[], right[];

USHORT make_table(USHORT nchar, UCHAR bitlen[], USHORT tablebits, USHORT table[]);

