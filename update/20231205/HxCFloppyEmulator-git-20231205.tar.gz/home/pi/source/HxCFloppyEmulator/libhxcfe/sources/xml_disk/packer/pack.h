
unsigned char data_pack(unsigned char * bufferin, uint32_t sizein,unsigned char * bufferout, int * sizeout);
unsigned char * data_unpack(unsigned char * bufferin, uint32_t sizein,unsigned char * bufferout, uint32_t sizeout);
