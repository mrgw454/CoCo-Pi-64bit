
USHORT Unpack_MEDIUM(UCHAR *, UCHAR *, USHORT);

extern USHORT medium_text_loc;

